const token = 'c06c0aae2b2c1949197d221b1e530ed224e6d25a';

module.exports.token = token;